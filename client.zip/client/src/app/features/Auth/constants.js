export const USER_LOGIN = 'features/Auth/USER_LOGIN';
export const USER_LOGOUT = 'features/Auth/USER_LOGOUT';