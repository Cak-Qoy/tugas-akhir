export const ADD_ITEM = 'features/Cart/ADD_ITEM';
export const REMOVE_ITEM = 'features/Cart/REMOVE_ITEM';
export const SET_ITEM = 'features/Cart/SET_ITEM';
export const CLEAR_ITEM = 'features/Cart/CLEAR_ITEM';